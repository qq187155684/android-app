package net.oschina.app.emoji;

import android.view.View;

public interface OnEmojiClickListener {
    void onDeleteButtonClick(View v);

    void onEmojiClick(Emojicon v);
}
