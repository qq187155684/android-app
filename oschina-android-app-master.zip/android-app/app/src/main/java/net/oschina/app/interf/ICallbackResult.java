package net.oschina.app.interf;

/** 
 * @author FireAnt（http://my.oschina.net/LittleDY）
 * @version 创建时间：2014年11月18日 上午11:18:28 
 * 
 */

public interface ICallbackResult {
	
	public void OnBackResult(Object s);
}
