package net.oschina.app.base;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by 火蚁 on 15/5/18.
 */
public class BaseNewActivity extends AppCompatActivity {


}
