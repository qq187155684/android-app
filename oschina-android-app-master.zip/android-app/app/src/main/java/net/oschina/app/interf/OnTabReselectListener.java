package net.oschina.app.interf;

/** 
 * 当tabHost再次被点击时
 * @author FireAnt（http://my.oschina.net/LittleDY）
 * @version 创建时间：2014年11月17日 上午11:00:15 
 * 
 */
public interface OnTabReselectListener {
	
	public void onTabReselect();
}
