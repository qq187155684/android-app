package net.oschina.app.interf;

/**
 * 
 * @author deyi
 *
 */
public interface BaseViewInterface {
	
	public void initView();
	
	public void initData();
	
}
